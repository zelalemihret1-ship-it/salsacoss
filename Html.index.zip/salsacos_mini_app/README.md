# Salsacos Telegram Mini App — complete starter project

Includes a Telegram bot, mobile-friendly Mini App, SQLite order storage, admin approval command, and a generic signed-webhook scaffold.

## Important: real automatic payment verification is not enabled yet

Telebirr/CBE phone or account numbers alone cannot verify a transaction. Provider-specific API credentials and official integration/callback documentation are required. The included `/payment-webhook` is only a scaffold: it expects a normalized callback signed with HMAC-SHA256. Do **not** expose it as a production payment verifier until you adapt it to the official provider callback format and signature rules. Never accept a customer-submitted screenshot, client-side status, or unsigned callback as proof of payment.

Until the official integrations are configured, Telebirr/CBE orders remain **PENDING PAYMENT** and do not receive a final order code. An administrator can verify payment independently and approve it with `/approve PENDING_REFERENCE`. Cash orders can be confirmed immediately.

## Files

- `bot.py` — Telegram bot, menu validation, SQLite storage, pending/approved orders, channel + admin notifications.
- `payment_webhook.py` — generic HMAC callback scaffold; requires provider-specific adaptation before production.
- `webapp/index.html` — Mini App frontend.
- `.env.example` — environment variables template.
- `requirements.txt` — Python dependencies.

## 1. Set up (Windows PowerShell)

```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

Set environment variables in PowerShell (or use your hosting provider's environment-variable settings):

```powershell
$env:BOT_TOKEN="YOUR_NEW_BOT_TOKEN"
$env:ORDER_CHANNEL="@salsacos"
$env:ADMIN_CHAT_ID="YOUR_NUMERIC_TELEGRAM_CHAT_ID"
$env:WEBAPP_URL="https://YOUR-DOMAIN.example/webapp/"
$env:DATABASE_PATH="salsacos_orders.sqlite3"
python bot.py
```

The code does not automatically load `.env`; set the variables in your hosting panel or shell. If you want `.env` auto-loading, install `python-dotenv` and add `load_dotenv()` before reading environment variables.

## 2. Telegram setup

1. If your bot token was previously pasted into a chat or source code, revoke it and generate a new token with `@BotFather`.
2. Add the bot as an administrator to `@salsacos` with permission to post messages.
3. Start the bot privately as the admin, send `/myid`, and use the numeric ID as `ADMIN_CHAT_ID`.
4. Host the `webapp` folder on a public HTTPS website. Set `WEBAPP_URL` to its `index.html` URL (or directory URL if your host serves `index.html` automatically).
5. Open the bot in Telegram and send `/start`.

## 3. Payment flow before provider API access

- Customer submits Telebirr/CBE order.
- Bot stores it as pending and sends the pending reference to the customer, channel, and configured admin.
- Customer contacts `@zilasun` with their payment evidence and pending reference.
- Admin verifies payment independently, then sends `/approve PENDING_REFERENCE` in the bot's private chat.
- Only then does the bot generate the final unique `SAL-XXXXXXXX` order code and send the confirmed receipt.

The admin approval command must only be used after checking the transaction in the official merchant app/account.

## 4. Automatic provider callbacks

`payment_webhook.py` is intentionally generic. It accepts a normalized JSON payload:

```json
{
  "provider": "telebirr",
  "merchant_reference": "PENDING_REFERENCE",
  "transaction_id": "PROVIDER_TRANSACTION_ID",
  "amount": 450,
  "currency": "ETB",
  "status": "SUCCESS"
}
```

The request must include `X-Webhook-Signature` containing the hex HMAC-SHA256 of the exact raw request body using `PAYMENT_WEBHOOK_SECRET`. This generic format is only an example contract, not a claim that Telebirr or CBE sends this format. You must write a provider adapter that validates the provider's official signature/authentication, fetches or verifies the transaction server-side, and maps its trusted response to this schema. Confirm exact amount, currency, merchant reference, transaction ID, and success status. Never rely only on a browser redirect.

Run the webhook scaffold separately after setting `PAYMENT_WEBHOOK_SECRET`:

```powershell
$env:PAYMENT_WEBHOOK_SECRET="A_LONG_RANDOM_SECRET"
uvicorn payment_webhook:app --host 0.0.0.0 --port 8080
```

Do not run this endpoint publicly as a real payment verifier until the provider-specific validation code is completed and tested. The scaffold deliberately fails closed when the secret is missing.
