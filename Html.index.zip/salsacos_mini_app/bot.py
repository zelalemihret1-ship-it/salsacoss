"""Salsacos Telegram bot. Electronic orders stay pending until verified."""
import os, json, logging, secrets, sqlite3, asyncio
from html import escape
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton, WebAppInfo
from telegram.constants import ParseMode
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters

BOT_TOKEN = os.getenv('BOT_TOKEN', '').strip()
ORDER_CHANNEL = os.getenv('ORDER_CHANNEL', '@salsacos').strip()
ADMIN_CHAT_ID = os.getenv('ADMIN_CHAT_ID', '').strip()
WEBAPP_URL = os.getenv('WEBAPP_URL', '').strip()
CUSTOMER_SERVICE_USERNAME = os.getenv('CUSTOMER_SERVICE_USERNAME', 'zilasun').strip().lstrip('@')
CUSTOMER_SERVICE_URL = f'https://t.me/{CUSTOMER_SERVICE_USERNAME}'
TELEBIRR_NUMBER = os.getenv('TELEBIRR_NUMBER', '0907490883').strip()
CBE_ACCOUNT = os.getenv('CBE_ACCOUNT', '1000539408872').strip()
DATABASE_PATH = os.getenv('DATABASE_PATH', 'salsacos_orders.sqlite3')
DELIVERY_FEE = 50
CURRENCY = 'ETB'
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(name)s: %(message)s')
log = logging.getLogger(__name__)

MENU = {
 'tacos': ('🌮 Tacos', 250, 'food'), 'special_tacos': ('🌮 Special Tacos', 300, 'food'),
 'wrap': ('🌯 Wrap', 200, 'food'), 'special_wrap': ('🌯 Special Wrap', 250, 'food'),
 'ketchup': ('🍅 Ketchup', 40, 'sauce'), 'mayonnaise': ('🥣 Mayonnaise', 40, 'sauce'),
 'salsacos_sauce': ('🌶️ Salsacos Sauce', 50, 'sauce'),
 'coca_cola': ('🥤 Coca-Cola', 70, 'soft_drinks'), 'fanta': ('🍊 Fanta', 70, 'soft_drinks'),
 'sprite': ('🍋 Sprite', 70, 'soft_drinks'), 'water': ('💧 Bottled Water', 50, 'soft_drinks'),
 'milkshake': ('🥤 Milkshake', 350, 'smoothies'), 'strawberry_shake': ('🍓 Strawberry Shake', 350, 'smoothies'),
 'strawberry_mojito': ('🍓 Strawberry Mojito', 450, 'mojitos'), 'mint_mojito': ('🌿 Mint Mojito', 450, 'mojitos'),
 'dashen_beer': ('🍺 Dashen Beer', 120, 'alcohol'), 'st_george_beer': ('🍺 St. George Beer', 120, 'alcohol'),
 'arada_beer': ('🍺 Arada Beer', 120, 'alcohol'),
}

def db():
    con = sqlite3.connect(DATABASE_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS orders (
          reference TEXT PRIMARY KEY, order_code TEXT UNIQUE, status TEXT NOT NULL,
          payment TEXT NOT NULL, amount REAL NOT NULL, currency TEXT NOT NULL,
          chat_id INTEGER NOT NULL, user_id INTEGER, payload TEXT NOT NULL,
          transaction_id TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')

def money(n): return f'{n:,.2f} {CURRENCY}'
def make_order_code(): return 'SAL-' + secrets.token_hex(4).upper()
def webapp_keyboard():
    if not WEBAPP_URL.startswith('https://'):
        return ReplyKeyboardMarkup([[KeyboardButton('🍽️ Open Salsacos Menu')]], resize_keyboard=True)
    return ReplyKeyboardMarkup([[KeyboardButton('🍽️ Open Salsacos Menu', web_app=WebAppInfo(url=WEBAPP_URL))]], resize_keyboard=True)

def render_items(payload):
    return '\n'.join(f'• {escape(row["name"])} × {row["qty"]} = <b>{money(row["price"] * row["qty"])}</b>' for row in payload['items'])

def order_type_label(value): return {'delivery':'🚚 Delivery','pickup':'🛍️ Self-pickup','dine_in':'🍽️ Dine-in'}[value]
def payment_label(value): return {'telebirr':'📱 Telebirr','cbe':'🏦 CBE','cash':'💵 Cash'}[value]

def pending_message(ref, payload):
    return (f'⏳ <b>PENDING SALSACOS ORDER</b>\nPayment reference: <code>{ref}</code>\n'
      f'{render_items(payload)}\n\nSubtotal: <b>{money(payload["subtotal"])}</b>\n'
      f'Delivery fee: <b>{money(payload["delivery_fee"])}</b>\nTotal: <b>{money(payload["amount"])}</b>\n\n'
      f'<b>Customer</b>\nName: {escape(payload["name"])}\nPhone: {escape(payload["phone"])}\n'
      f'Address: {escape(payload["address"] or "Not required")}\nTelegram: {escape(payload["username"])}\n'
      f'Telegram ID: <code>{payload["user_id"]}</code>\nOrder type: {order_type_label(payload["order_type"])}\n'
      f'Payment: {payment_label(payload["payment"])}\nStatus: <b>PENDING PAYMENT VERIFICATION</b>')

async def notify_pending(context, ref, payload):
    text = pending_message(ref, payload)
    jobs = [context.bot.send_message(chat_id=ORDER_CHANNEL, text=text, parse_mode=ParseMode.HTML)]
    if ADMIN_CHAT_ID:
        jobs.append(context.bot.send_message(chat_id=int(ADMIN_CHAT_ID), text='🔔 <b>ADMIN COPY</b>\n\n'+text, parse_mode=ParseMode.HTML))
    results = await asyncio.gather(*jobs, return_exceptions=True)
    if isinstance(results[0], Exception): raise results[0]
    if len(results) > 1 and isinstance(results[1], Exception): log.error('Admin copy failed: %s', results[1])

async def notify_confirmed(bot, row, code, transaction_id=''):
    payload = json.loads(row['payload'])
    ref = row['reference']
    tx_line = f'\nTransaction ID: <code>{escape(transaction_id)}</code>' if transaction_id else ''
    text = (f'✅ <b>SALSACOS ORDER CONFIRMED</b>\n🧾 Order code: <code>{code}</code>\n'
      f'Payment reference: <code>{ref}</code>{tx_line}\n━━━━━━━━━━━━━━\n{render_items(payload)}\n\n'
      f'Subtotal: <b>{money(payload["subtotal"])}</b>\nDelivery fee: <b>{money(payload["delivery_fee"])}</b>\n'
      f'Total: <b>{money(payload["amount"])}</b>\n\nCustomer: {escape(payload["name"])}\nPhone: {escape(payload["phone"])}\n'
      f'Address: {escape(payload["address"] or "Not required")}\nTelegram ID: <code>{payload["user_id"]}</code>\n'
      f'Order type: {order_type_label(payload["order_type"])}\nPayment: {payment_label(payload["payment"])}\nStatus: <b>{"CASH ON ARRIVAL / ACCEPTED" if payload["payment"] == "cash" else "PAYMENT VERIFIED"}</b>')
    jobs = [bot.send_message(chat_id=ORDER_CHANNEL, text=text, parse_mode=ParseMode.HTML)]
    if ADMIN_CHAT_ID: jobs.append(bot.send_message(chat_id=int(ADMIN_CHAT_ID), text='🔔 <b>ADMIN COPY</b>\n\n'+text, parse_mode=ParseMode.HTML))
    jobs.append(bot.send_message(chat_id=row['chat_id'], text=(f'🎉 <b>Payment verified — thank you for ordering from Salsacos!</b>\n\n'
      f'Your unique order code: <code>{code}</code>\n\n{render_items(payload)}\n\nTotal: <b>{money(payload["amount"])}</b>\n'
      f'Order type: {order_type_label(payload["order_type"])}\nPayment status: <b>{"PAY ON ARRIVAL" if payload["payment"] == "cash" else "VERIFIED"}</b>\n\n'
      f'For help, contact @{CUSTOMER_SERVICE_USERNAME}.\nTo place another order, send /start.'),
      parse_mode=ParseMode.HTML, reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('📩 Customer Service', url=CUSTOMER_SERVICE_URL)]])))
    results = await asyncio.gather(*jobs, return_exceptions=True)
    for i, result in enumerate(results):
        if isinstance(result, Exception): log.error('Confirmation notification %s failed: %s', i, result)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text('🍽️ Welcome to Salsacos!\n\nTap below to open our menu and place your order.\n🚚 Delivery fee: 50 birr.\n\nFor support, contact @'+CUSTOMER_SERVICE_USERNAME+'.', reply_markup=webapp_keyboard())

async def receive_webapp_order(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.effective_message
    user = update.effective_user
    if not msg or not msg.web_app_data or not user: return
    try:
        data = json.loads(msg.web_app_data.data)
        if data.get('type') != 'salsacos_order': raise ValueError('Invalid order type')
        items = data.get('items')
        if not isinstance(items, list) or not items: raise ValueError('Empty cart')
        clean, subtotal, alcohol_present = [], 0, False
        for row in items:
            if not isinstance(row, dict): raise ValueError('Invalid item row')
            item_id, qty = row.get('id'), row.get('qty')
            if item_id not in MENU or not isinstance(qty, int) or isinstance(qty, bool) or not 1 <= qty <= 50: raise ValueError('Invalid item')
            item_name, price, category = MENU[item_id]
            alcohol_present |= category == 'alcohol'
            subtotal += price * qty
            clean.append({'id':item_id, 'name':item_name, 'qty':qty, 'price':price})
        if alcohol_present and data.get('age_confirmed') is not True: raise ValueError('Age confirmation required')
        order_type, payment = data.get('order_type'), data.get('payment')
        if order_type not in ('delivery','pickup','dine_in'): raise ValueError('Invalid order type')
        if payment not in ('telebirr','cbe','cash'): raise ValueError('Invalid payment')
        name, phone, address = str(data.get('name','')).strip()[:100], str(data.get('phone','')).strip()[:40], str(data.get('address','')).strip()[:300]
        if len(name) < 2 or len(phone) < 7: raise ValueError('Name or phone is invalid')
        if order_type == 'delivery' and len(address) < 3: raise ValueError('Delivery address required')
        delivery_fee = DELIVERY_FEE if order_type == 'delivery' else 0
        amount = subtotal + delivery_fee
        reference = 'SP-' + secrets.token_hex(5).upper()
        username = '@'+user.username if user.username else 'Not provided'
        payload = {'items':clean,'subtotal':subtotal,'delivery_fee':delivery_fee,'amount':amount,'name':name,'phone':phone,'address':address if order_type=='delivery' else 'Not required','username':username,'user_id':user.id,'order_type':order_type,'payment':payment}
        status = 'CONFIRMED_CASH' if payment == 'cash' else 'PENDING_PAYMENT'
        code = make_order_code() if payment == 'cash' else None
        with db() as con:
            con.execute('INSERT INTO orders(reference,order_code,status,payment,amount,currency,chat_id,user_id,payload) VALUES(?,?,?,?,?,?,?,?,?)',
                (reference,code,status,payment,amount,CURRENCY,msg.chat_id,user.id,json.dumps(payload,ensure_ascii=False)))
        if payment == 'cash':
            # Cash orders are accepted as cash-on-delivery / pay-at-restaurant, not marked as paid.
            with db() as con:
                row = dict(con.execute('SELECT * FROM orders WHERE reference=?',(reference,)).fetchone())
            await notify_confirmed(context.bot, row, code, 'CASH PAYMENT — COLLECT ON ARRIVAL')
        else:
            await notify_pending(context, reference, payload)
            payment_info = f'Telebirr number: {TELEBIRR_NUMBER}' if payment == 'telebirr' else f'CBE account: {CBE_ACCOUNT}'
            await msg.reply_text(
                f'⏳ Your order request was received, but payment is NOT yet verified.\n\nPayment reference: {reference}\n'
                f'Total: {money(amount)}\n{payment_info}\n\nDo not treat this reference as a confirmed order code. After paying, send your receipt and reference to @{CUSTOMER_SERVICE_USERNAME}. '
                f'Your final SAL order code and confirmation will be sent only after the restaurant verifies the payment.\n\nTo place another order, send /start.',
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton('📩 Customer Service', url=CUSTOMER_SERVICE_URL)]]))
    except Exception as exc:
        log.exception('Could not process Mini App order: %s', exc)
        await msg.reply_text('Sorry, we could not submit your order. Check your details and try again, or contact @'+CUSTOMER_SERVICE_USERNAME+'.')

async def approve_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if not user or not ADMIN_CHAT_ID or str(update.effective_chat.id) != ADMIN_CHAT_ID:
        await update.effective_message.reply_text('This command is available only in the configured admin chat.')
        return
    if len(context.args) != 1:
        await update.effective_message.reply_text('Usage: /approve PAYMENT_REFERENCE\nVerify the payment in the official merchant account before approving.')
        return
    ref = context.args[0].strip().upper()
    with db() as con:
        row = con.execute('SELECT * FROM orders WHERE reference=?',(ref,)).fetchone()
        if not row:
            await update.effective_message.reply_text('Reference not found.')
            return
        if row['status'] != 'PENDING_PAYMENT':
            await update.effective_message.reply_text(f'Cannot approve: current status is {row["status"]}.')
            return
        code = make_order_code()
        con.execute("UPDATE orders SET status='PAYMENT_VERIFIED',order_code=?,updated_at=CURRENT_TIMESTAMP WHERE reference=? AND status='PENDING_PAYMENT'",(code,ref))
        updated = con.execute('SELECT * FROM orders WHERE reference=?',(ref,)).fetchone()
    await notify_confirmed(context.bot, dict(updated), code, 'ADMIN VERIFIED')
    await update.effective_message.reply_text(f'Approved {ref}. Final order code: {code}')

async def myid_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(f'Your Telegram user ID: {update.effective_user.id}\nThis chat ID: {update.effective_chat.id}\nUse this chat ID as ADMIN_CHAT_ID.')
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text('Send /start to open Salsacos ordering. Admins: /approve PAYMENT_REFERENCE after independently verifying payment.')

def main():
    if not BOT_TOKEN: raise SystemExit('Set BOT_TOKEN environment variable before running the bot.')
    if ADMIN_CHAT_ID and not ADMIN_CHAT_ID.lstrip('-').isdigit(): raise SystemExit('ADMIN_CHAT_ID must be numeric. Use /myid.')
    if not WEBAPP_URL.startswith('https://'): log.warning('Set WEBAPP_URL to a public HTTPS URL for the Mini App button.')
    init_db()
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler('start', start)); app.add_handler(CommandHandler('help', help_command)); app.add_handler(CommandHandler('myid', myid_command)); app.add_handler(CommandHandler('approve', approve_command))
    app.add_handler(MessageHandler(filters.StatusUpdate.WEB_APP_DATA, receive_webapp_order))
    log.info('Starting Salsacos Mini App bot')
    app.run_polling(allowed_updates=Update.ALL_TYPES)
if __name__ == '__main__': main()
