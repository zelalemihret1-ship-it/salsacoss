"""Generic signed webhook receiver scaffold — adapt to official provider callbacks first.

This is NOT a ready-made Telebirr or CBE adapter. Provider-specific authentication,
signature verification, and server-side transaction lookup must be implemented from
the merchant's official documentation before exposing this endpoint publicly.
"""
import os, json, hmac, hashlib, logging, sqlite3
from decimal import Decimal, InvalidOperation
from fastapi import FastAPI, Request, HTTPException
from telegram import Bot
from bot import (BOT_TOKEN, ADMIN_CHAT_ID, ORDER_CHANNEL, DATABASE_PATH, CURRENCY,
                 notify_confirmed, make_order_code, init_db)

app = FastAPI(title='Salsacos Payment Callback Scaffold')
log = logging.getLogger(__name__)
WEBHOOK_SECRET = os.getenv('PAYMENT_WEBHOOK_SECRET', '').strip()

@app.get('/health')
async def health():
    return {'ok': True, 'mode': 'scaffold_only', 'payment_verification_enabled': False}

@app.post('/payment-webhook')
async def payment_webhook(request: Request):
    # Fail closed when no secret is configured. A secret alone does not replace
    # official provider signature verification or transaction-status lookup.
    if not WEBHOOK_SECRET:
        raise HTTPException(status_code=503, detail='Payment callback is not configured')
    raw = await request.body()
    supplied = request.headers.get('X-Webhook-Signature', '').strip().lower()
    expected = hmac.new(WEBHOOK_SECRET.encode(), raw, hashlib.sha256).hexdigest()
    if not supplied or not hmac.compare_digest(supplied, expected):
        raise HTTPException(status_code=401, detail='Invalid callback signature')
    try:
        data = json.loads(raw)
        provider = str(data['provider']).lower()
        reference = str(data['merchant_reference']).upper()
        transaction_id = str(data['transaction_id']).strip()
        amount = Decimal(str(data['amount']))
        currency = str(data['currency']).upper()
        status = str(data['status']).upper()
    except (ValueError, KeyError, TypeError, InvalidOperation):
        raise HTTPException(status_code=400, detail='Malformed callback payload')
    if provider not in ('telebirr', 'cbe') or not transaction_id or len(transaction_id) > 200:
        raise HTTPException(status_code=400, detail='Invalid provider or transaction ID')
    if status not in ('SUCCESS', 'COMPLETED', 'PAID'):
        # A failed/pending callback must never confirm an order.
        return {'ok': True, 'ignored': True, 'reason': 'transaction_not_successful'}
    init_db()
    con = sqlite3.connect(DATABASE_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    try:
        row = con.execute('SELECT * FROM orders WHERE reference=?', (reference,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail='Unknown payment reference')
        if row['payment'] != provider:
            raise HTTPException(status_code=400, detail='Payment provider does not match order')
        if currency != CURRENCY or Decimal(str(row['amount'])) != amount:
            raise HTTPException(status_code=400, detail='Amount or currency mismatch')
        if row['status'] == 'PAYMENT_VERIFIED':
            # Idempotent duplicate delivery is okay only for the same transaction.
            if row['transaction_id'] == transaction_id:
                return {'ok': True, 'already_processed': True}
            raise HTTPException(status_code=409, detail='Order already paid with a different transaction')
        if row['status'] != 'PENDING_PAYMENT':
            raise HTTPException(status_code=409, detail='Order is not awaiting payment')
        # IMPORTANT: This state transition is safe only if the signature above
        # authenticates the trusted provider callback and the adapter has verified
        # transaction status server-side. Do not use raw untrusted provider payloads.
        code = make_order_code()
        cur = con.execute("UPDATE orders SET status='PAYMENT_VERIFIED',order_code=?,transaction_id=?,updated_at=CURRENT_TIMESTAMP WHERE reference=? AND status='PENDING_PAYMENT'",
                          (code, transaction_id, reference))
        if cur.rowcount != 1:
            raise HTTPException(status_code=409, detail='Order status changed concurrently')
        con.commit()
        updated = con.execute('SELECT * FROM orders WHERE reference=?', (reference,)).fetchone()
    finally:
        con.close()
    if not BOT_TOKEN:
        log.error('Payment was marked verified but BOT_TOKEN is missing; notifications could not be sent')
        raise HTTPException(status_code=500, detail='Bot notification configuration missing')
    async with Bot(BOT_TOKEN) as bot:
        await notify_confirmed(bot, dict(updated), code, transaction_id)
    return {'ok': True, 'order_code': code}
